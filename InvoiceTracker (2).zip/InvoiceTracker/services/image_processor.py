"""
Image processing service for text masking and inpainting
Uses OpenCV for professional text removal
"""

import os
import asyncio
import logging
from typing import List, Dict, Any
import cv2
import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

class ImageProcessor:
    def __init__(self):
        """Initialize image processor"""
        logger.info("Image processor initialized")
    
    async def mask_text_regions(self, image_path: str, text_results: List[Dict[str, Any]], temp_dir: str) -> str:
        """
        Mask text regions using OpenCV inpainting
        
        Args:
            image_path: Path to input image
            text_results: List of text detection results with bbox
            temp_dir: Temporary directory for output
            
        Returns:
            Path to the masked image
        """
        try:
            # Run processing in thread pool
            loop = asyncio.get_event_loop()
            masked_path = await loop.run_in_executor(
                None, self._mask_text_sync, image_path, text_results, temp_dir
            )
            
            return masked_path
            
        except Exception as e:
            logger.error(f"Error masking text regions: {str(e)}")
            # Return original image path if masking fails
            output_path = os.path.join(temp_dir, "masked_image.png")
            self.copy_image(image_path, output_path)
            return output_path
    
    def _mask_text_sync(self, image_path: str, text_results: List[Dict[str, Any]], temp_dir: str) -> str:
        """Synchronous text masking"""
        try:
            # Load image
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            height, width = image.shape[:2]
            
            # Create mask for all text regions
            mask = np.zeros((height, width), dtype=np.uint8)
            
            for text_result in text_results:
                bbox = text_result['bbox']
                # Expand bbox slightly for better coverage
                expanded_bbox = self._expand_bbox(bbox, 0.15)  # 15% expansion
                
                # Convert bbox to contour
                pts = np.array(expanded_bbox, dtype=np.int32)
                
                # Fill the polygon
                cv2.fillPoly(mask, [pts], 255)
            
            # Apply morphological operations to improve mask
            kernel = np.ones((3, 3), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, kernel)
            
            # Apply inpainting
            inpainted = cv2.inpaint(image, mask, inpaintRadius=3, flags=cv2.INPAINT_TELEA)
            
            # Save masked image
            output_path = os.path.join(temp_dir, "masked_image.png")
            cv2.imwrite(output_path, inpainted)
            
            logger.info(f"Text masking completed: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Sync text masking failed: {str(e)}")
            raise
    
    def _expand_bbox(self, bbox: List[List[int]], expansion_ratio: float = 0.1) -> List[List[int]]:
        """Expand bounding box for better text coverage"""
        try:
            # Get bbox bounds
            x_coords = [point[0] for point in bbox]
            y_coords = [point[1] for point in bbox]
            
            min_x, max_x = min(x_coords), max(x_coords)
            min_y, max_y = min(y_coords), max(y_coords)
            
            width = max_x - min_x
            height = max_y - min_y
            
            # Calculate expansion
            x_expansion = width * expansion_ratio
            y_expansion = height * expansion_ratio
            
            # Expand and ensure positive coordinates
            expanded_bbox = [
                [max(0, int(min_x - x_expansion)), max(0, int(min_y - y_expansion))],
                [int(max_x + x_expansion), max(0, int(min_y - y_expansion))],
                [int(max_x + x_expansion), int(max_y + y_expansion)],
                [max(0, int(min_x - x_expansion)), int(max_y + y_expansion)]
            ]
            
            return expanded_bbox
            
        except Exception as e:
            logger.error(f"Error expanding bbox: {str(e)}")
            return bbox
    
    def copy_image(self, source_path: str, destination_path: str):
        """Copy image from source to destination"""
        try:
            image = cv2.imread(source_path)
            cv2.imwrite(destination_path, image)
        except Exception as e:
            logger.error(f"Error copying image: {str(e)}")
            raise
    
    def resize_image_if_needed(self, image_path: str, max_dimension: int = 2048) -> str:
        """
        Resize image if it's too large for processing
        
        Args:
            image_path: Path to image
            max_dimension: Maximum width or height
            
        Returns:
            Path to resized image (same as input if no resize needed)
        """
        try:
            image = cv2.imread(image_path)
            height, width = image.shape[:2]
            
            if max(height, width) <= max_dimension:
                return image_path  # No resize needed
            
            # Calculate new dimensions
            if width > height:
                new_width = max_dimension
                new_height = int(height * (max_dimension / width))
            else:
                new_height = max_dimension
                new_width = int(width * (max_dimension / height))
            
            # Resize image
            resized = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
            
            # Save resized image
            resized_path = image_path.replace('.', '_resized.')
            cv2.imwrite(resized_path, resized)
            
            logger.info(f"Image resized from {width}x{height} to {new_width}x{new_height}")
            return resized_path
            
        except Exception as e:
            logger.error(f"Error resizing image: {str(e)}")
            return image_path
    
    def enhance_image_for_ocr(self, image_path: str, temp_dir: str) -> str:
        """
        Enhance image for better OCR results
        
        Args:
            image_path: Path to input image
            temp_dir: Temporary directory
            
        Returns:
            Path to enhanced image
        """
        try:
            image = cv2.imread(image_path)
            
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Apply denoising
            denoised = cv2.fastNlMeansDenoising(gray)
            
            # Apply adaptive thresholding for better text contrast
            adaptive_thresh = cv2.adaptiveThreshold(
                denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
            
            # Convert back to BGR for consistency
            enhanced = cv2.cvtColor(adaptive_thresh, cv2.COLOR_GRAY2BGR)
            
            # Save enhanced image
            enhanced_path = os.path.join(temp_dir, "enhanced_image.png")
            cv2.imwrite(enhanced_path, enhanced)
            
            return enhanced_path
            
        except Exception as e:
            logger.error(f"Error enhancing image: {str(e)}")
            return image_path
