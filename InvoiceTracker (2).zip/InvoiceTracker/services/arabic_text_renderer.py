"""
Arabic text rendering service
Handles proper RTL text rendering with font sizing and positioning
"""

import os
import asyncio
import logging
from typing import List, Dict, Any, Tuple
import math

from PIL import Image, ImageDraw, ImageFont
import arabic_reshaper
from bidi.algorithm import get_display
import numpy as np

logger = logging.getLogger(__name__)

class ArabicTextRenderer:
    def __init__(self):
        """Initialize Arabic text renderer"""
        self.font_path = "fonts/Amiri-Regular.ttf"
        self.fallback_font_size = 20
        logger.info("Arabic text renderer initialized")
    
    async def render_arabic_text(
        self, 
        image_path: str, 
        translated_results: List[Dict[str, Any]], 
        temp_dir: str
    ) -> str:
        """
        Render Arabic text on the image
        
        Args:
            image_path: Path to the masked image
            translated_results: List of translation results with bbox and text
            temp_dir: Temporary directory for output
            
        Returns:
            Path to the final rendered image
        """
        try:
            # Run rendering in thread pool
            loop = asyncio.get_event_loop()
            rendered_path = await loop.run_in_executor(
                None, self._render_text_sync, image_path, translated_results, temp_dir
            )
            
            return rendered_path
            
        except Exception as e:
            logger.error(f"Error rendering Arabic text: {str(e)}")
            # Return original image if rendering fails
            output_path = os.path.join(temp_dir, "final_image.png")
            with Image.open(image_path) as img:
                img.save(output_path, "PNG")
            return output_path
    
    def _render_text_sync(
        self, 
        image_path: str, 
        translated_results: List[Dict[str, Any]], 
        temp_dir: str
    ) -> str:
        """Synchronous text rendering"""
        try:
            # Load image
            with Image.open(image_path) as img:
                # Convert to RGB if necessary
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                draw = ImageDraw.Draw(img)
                
                # Render each text segment
                for result in translated_results:
                    try:
                        self._render_single_text(draw, result, img.size)
                    except Exception as e:
                        logger.error(f"Failed to render text '{result.get('translated_text', '')}': {str(e)}")
                        continue
                
                # Save final image
                output_path = os.path.join(temp_dir, "final_image.png")
                img.save(output_path, "PNG")
                
                logger.info(f"Arabic text rendering completed: {output_path}")
                return output_path
                
        except Exception as e:
            logger.error(f"Sync text rendering failed: {str(e)}")
            raise
    
    def _render_single_text(self, draw: ImageDraw.Draw, result: Dict[str, Any], image_size: Tuple[int, int]):
        """Render a single text segment"""
        try:
            translated_text = result['translated_text']
            bbox = result['bbox']
            
            if not translated_text.strip():
                return
            
            # Calculate bbox dimensions
            bbox_width, bbox_height = self._calculate_bbox_dimensions(bbox)
            bbox_center = self._calculate_bbox_center(bbox)
            
            # Prepare Arabic text for rendering
            reshaped_text = arabic_reshaper.reshape(translated_text)
            display_text = get_display(reshaped_text)
            
            # Calculate appropriate font size
            font_size = self._calculate_font_size(
                draw, display_text, bbox_width, bbox_height
            )
            
            # Load font
            font = self._load_font(font_size)
            
            # Get text dimensions
            bbox_text = draw.textbbox((0, 0), display_text, font=font)
            text_width = bbox_text[2] - bbox_text[0]
            text_height = bbox_text[3] - bbox_text[1]
            
            # Calculate text position (center in bbox)
            text_x = bbox_center[0] - text_width // 2
            text_y = bbox_center[1] - text_height // 2
            
            # Ensure text is within image bounds
            text_x = max(0, min(text_x, image_size[0] - text_width))
            text_y = max(0, min(text_y, image_size[1] - text_height))
            
            # Draw text with outline for better visibility
            outline_width = max(1, font_size // 20)
            
            # Draw outline
            for adj in range(-outline_width, outline_width + 1):
                for adj2 in range(-outline_width, outline_width + 1):
                    if adj != 0 or adj2 != 0:
                        draw.text(
                            (text_x + adj, text_y + adj2), 
                            display_text, 
                            font=font, 
                            fill='white'
                        )
            
            # Draw main text
            draw.text((text_x, text_y), display_text, font=font, fill='black')
            
        except Exception as e:
            logger.error(f"Error rendering single text: {str(e)}")
    
    def _calculate_bbox_dimensions(self, bbox: List[List[int]]) -> Tuple[int, int]:
        """Calculate width and height of bounding box"""
        x_coords = [point[0] for point in bbox]
        y_coords = [point[1] for point in bbox]
        
        width = max(x_coords) - min(x_coords)
        height = max(y_coords) - min(y_coords)
        
        return width, height
    
    def _calculate_bbox_center(self, bbox: List[List[int]]) -> Tuple[int, int]:
        """Calculate center point of bounding box"""
        x_coords = [point[0] for point in bbox]
        y_coords = [point[1] for point in bbox]
        
        center_x = (max(x_coords) + min(x_coords)) // 2
        center_y = (max(y_coords) + min(y_coords)) // 2
        
        return center_x, center_y
    
    def _calculate_font_size(
        self, 
        draw: ImageDraw.Draw, 
        text: str, 
        target_width: int, 
        target_height: int
    ) -> int:
        """Calculate appropriate font size to fit in the bounding box"""
        try:
            # Start with a reasonable font size
            min_size = 8
            max_size = min(target_height, 100)  # Cap at reasonable maximum
            
            if max_size < min_size:
                return min_size
            
            # Binary search for optimal font size
            best_size = min_size
            
            for size in range(min_size, max_size + 1, 2):
                try:
                    font = self._load_font(size)
                    bbox_text = draw.textbbox((0, 0), text, font=font)
                    text_width = bbox_text[2] - bbox_text[0]
                    text_height = bbox_text[3] - bbox_text[1]
                    
                    # Check if text fits with some margin
                    margin_factor = 0.9  # Use 90% of available space
                    if (text_width <= target_width * margin_factor and 
                        text_height <= target_height * margin_factor):
                        best_size = size
                    else:
                        break
                        
                except Exception:
                    continue
            
            return max(best_size, min_size)
            
        except Exception as e:
            logger.error(f"Error calculating font size: {str(e)}")
            return self.fallback_font_size
    
    def _load_font(self, size: int) -> ImageFont.FreeTypeFont:
        """Load Arabic font with specified size"""
        try:
            if os.path.exists(self.font_path):
                return ImageFont.truetype(self.font_path, size)
            else:
                logger.warning(f"Font file not found: {self.font_path}")
                # Try to use default font
                return ImageFont.load_default()
                
        except Exception as e:
            logger.error(f"Error loading font: {str(e)}")
            return ImageFont.load_default()
    
    def _get_text_color(self, image: Image.Image, bbox: List[List[int]]) -> str:
        """
        Determine appropriate text color based on background
        
        Args:
            image: PIL Image
            bbox: Bounding box coordinates
            
        Returns:
            Color string ('black' or 'white')
        """
        try:
            # Convert to numpy array for analysis
            img_array = np.array(image)
            
            # Get bbox bounds
            x_coords = [point[0] for point in bbox]
            y_coords = [point[1] for point in bbox]
            
            min_x, max_x = max(0, min(x_coords)), min(img_array.shape[1], max(x_coords))
            min_y, max_y = max(0, min(y_coords)), min(img_array.shape[0], max(y_coords))
            
            # Extract region
            region = img_array[min_y:max_y, min_x:max_x]
            
            if region.size == 0:
                return 'black'  # Default
            
            # Calculate average brightness
            avg_brightness = np.mean(region)
            
            # Return appropriate contrast color
            return 'black' if avg_brightness > 127 else 'white'
            
        except Exception as e:
            logger.error(f"Error determining text color: {str(e)}")
            return 'black'  # Default to black
