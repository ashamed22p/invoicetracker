"""
Fallback text extraction service 
Provides structure for when EasyOCR is not available
"""

import asyncio
import logging
from typing import List, Dict, Any
import numpy as np

logger = logging.getLogger(__name__)

class TextExtractorFallback:
    def __init__(self):
        """Initialize fallback text extractor"""
        logger.info("Fallback text extractor initialized (EasyOCR not available)")
    
    async def extract_text_with_boxes(self, image_path: str) -> List[Dict[str, Any]]:
        """
        Fallback text extraction - returns empty list
        """
        logger.warning(f"OCR not available for {image_path} - install EasyOCR for text extraction")
        return []
    
    def get_text_mask(self, image_shape: tuple, bbox_list: List[List]) -> np.ndarray:
        """Create a basic mask"""
        height, width = image_shape[:2]
        return np.zeros((height, width), dtype=np.uint8)
    
    def expand_bbox(self, bbox: List[List[int]], expansion_ratio: float = 0.1) -> List[List[int]]:
        """Return bbox unchanged in fallback mode"""
        return bbox