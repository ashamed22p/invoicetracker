"""
Text translation service using deep-translator
Translates text to Arabic with language detection
"""

import asyncio
import logging
from typing import Optional
from deep_translator import GoogleTranslator
import re

logger = logging.getLogger(__name__)

class TextTranslator:
    def __init__(self):
        """Initialize translator"""
        try:
            self.translator = GoogleTranslator(source='auto', target='ar')
            logger.info("Text translator initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize translator: {str(e)}")
            raise
    
    async def translate_to_arabic(self, text: str) -> str:
        """
        Translate text to Arabic
        
        Args:
            text: Text to translate
            
        Returns:
            Translated Arabic text
        """
        try:
            # Clean and validate input text
            cleaned_text = self._clean_text(text)
            if not cleaned_text:
                return ""
            
            # Skip if already Arabic
            if self._is_arabic(cleaned_text):
                logger.debug(f"Text already in Arabic: {cleaned_text}")
                return cleaned_text
            
            # Translate in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            translated = await loop.run_in_executor(None, self._translate_sync, cleaned_text)
            
            if translated:
                logger.debug(f"Translated: '{cleaned_text}' -> '{translated}'")
                return translated
            else:
                logger.warning(f"Translation failed for: {cleaned_text}")
                return cleaned_text  # Return original if translation fails
                
        except Exception as e:
            logger.error(f"Error translating text '{text}': {str(e)}")
            return text  # Return original text on error
    
    def _translate_sync(self, text: str) -> Optional[str]:
        """Synchronous translation"""
        try:
            # Handle short text differently
            if len(text.strip()) <= 2:
                return text  # Don't translate very short text
            
            translated = self.translator.translate(text)
            return translated if translated else text
            
        except Exception as e:
            logger.error(f"Sync translation failed: {str(e)}")
            return text
    
    def _clean_text(self, text: str) -> str:
        """
        Clean text before translation
        
        Args:
            text: Raw text from OCR
            
        Returns:
            Cleaned text
        """
        if not text:
            return ""
        
        # Remove excessive whitespace
        cleaned = re.sub(r'\s+', ' ', text.strip())
        
        # Remove special characters that might interfere with translation
        # Keep basic punctuation
        cleaned = re.sub(r'[^\w\s\.,!?;:()\'"-]', ' ', cleaned)
        
        # Remove single characters (likely OCR errors)
        if len(cleaned.strip()) <= 1:
            return ""
        
        return cleaned.strip()
    
    def _is_arabic(self, text: str) -> bool:
        """
        Check if text is already in Arabic
        
        Args:
            text: Text to check
            
        Returns:
            True if text contains Arabic characters
        """
        # Check for Arabic Unicode range
        arabic_pattern = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')
        return bool(arabic_pattern.search(text))
    
    async def detect_language(self, text: str) -> Optional[str]:
        """
        Detect the language of input text
        
        Args:
            text: Text to analyze
            
        Returns:
            Language code or None if detection fails
        """
        try:
            from deep_translator import single_detection
            
            loop = asyncio.get_event_loop()
            language = await loop.run_in_executor(None, single_detection, text, 'langdetect')
            
            logger.debug(f"Detected language for '{text}': {language}")
            return language
            
        except Exception as e:
            logger.error(f"Language detection failed: {str(e)}")
            return None
    
    async def translate_batch(self, texts: list) -> list:
        """
        Translate multiple texts efficiently
        
        Args:
            texts: List of texts to translate
            
        Returns:
            List of translated texts in the same order
        """
        try:
            tasks = [self.translate_to_arabic(text) for text in texts]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Handle exceptions in results
            translated_texts = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"Translation failed for text {i}: {result}")
                    translated_texts.append(texts[i])  # Use original text on error
                else:
                    translated_texts.append(result)
            
            return translated_texts
            
        except Exception as e:
            logger.error(f"Batch translation failed: {str(e)}")
            return texts  # Return original texts on error
