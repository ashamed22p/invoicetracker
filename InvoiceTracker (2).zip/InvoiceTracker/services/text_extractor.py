"""
Text extraction service using EasyOCR
Extracts text from images with bounding box coordinates
"""

import asyncio
import logging
from typing import List, Dict, Any
import easyocr
import numpy as np
from PIL import Image
import cv2

logger = logging.getLogger(__name__)

class TextExtractor:
    def __init__(self):
        """Initialize EasyOCR reader"""
        try:
            # Initialize EasyOCR with multiple languages for better detection
            self.reader = easyocr.Reader(['en', 'ar', 'fr', 'es', 'de', 'it', 'pt', 'ru', 'ja', 'ko', 'zh'])
            logger.info("EasyOCR initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize EasyOCR: {str(e)}")
            raise
    
    async def extract_text_with_boxes(self, image_path: str) -> List[Dict[str, Any]]:
        """
        Extract text from image with bounding box coordinates
        
        Args:
            image_path: Path to the image file
            
        Returns:
            List of dictionaries containing:
            - text: extracted text
            - bbox: bounding box coordinates [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]
            - confidence: confidence score
        """
        try:
            # Run OCR in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(None, self._extract_sync, image_path)
            
            # Process results
            text_results = []
            for (bbox, text, confidence) in results:
                if text.strip() and confidence > 0.3:  # Filter low confidence detections
                    text_results.append({
                        'text': text.strip(),
                        'bbox': bbox,
                        'confidence': confidence
                    })
            
            logger.info(f"Extracted {len(text_results)} text segments from {image_path}")
            return text_results
            
        except Exception as e:
            logger.error(f"Error extracting text from {image_path}: {str(e)}")
            return []
    
    def _extract_sync(self, image_path: str):
        """Synchronous text extraction"""
        try:
            # Load and preprocess image
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            # Convert BGR to RGB for EasyOCR
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Extract text with detailed output
            results = self.reader.readtext(
                image_rgb,
                detail=1,  # Return bounding boxes and confidence
                paragraph=False,  # Don't group text into paragraphs
                width_ths=0.7,  # Width threshold for text grouping
                height_ths=0.7,  # Height threshold for text grouping
                text_threshold=0.7,  # Text confidence threshold
                low_text=0.4  # Low text threshold
            )
            
            return results
            
        except Exception as e:
            logger.error(f"Sync text extraction failed: {str(e)}")
            return []
    
    def get_text_mask(self, image_shape: tuple, bbox_list: List[List]) -> np.ndarray:
        """
        Create a mask for text regions
        
        Args:
            image_shape: Shape of the image (height, width, channels)
            bbox_list: List of bounding boxes
            
        Returns:
            Binary mask where text regions are white (255) and rest is black (0)
        """
        try:
            height, width = image_shape[:2]
            mask = np.zeros((height, width), dtype=np.uint8)
            
            for bbox in bbox_list:
                # Convert bbox to numpy array of integer coordinates
                pts = np.array(bbox, dtype=np.int32)
                
                # Fill the polygon defined by the bbox
                cv2.fillPoly(mask, [pts], 255)
            
            return mask
            
        except Exception as e:
            logger.error(f"Error creating text mask: {str(e)}")
            return np.zeros((image_shape[0], image_shape[1]), dtype=np.uint8)
    
    def expand_bbox(self, bbox: List[List[int]], expansion_ratio: float = 0.1) -> List[List[int]]:
        """
        Expand bounding box by a given ratio to ensure complete text coverage
        
        Args:
            bbox: Bounding box coordinates
            expansion_ratio: Ratio to expand the bbox (0.1 = 10% expansion)
            
        Returns:
            Expanded bounding box
        """
        try:
            # Calculate bbox center and dimensions
            x_coords = [point[0] for point in bbox]
            y_coords = [point[1] for point in bbox]
            
            min_x, max_x = min(x_coords), max(x_coords)
            min_y, max_y = min(y_coords), max(y_coords)
            
            width = max_x - min_x
            height = max_y - min_y
            
            # Calculate expansion
            x_expansion = width * expansion_ratio
            y_expansion = height * expansion_ratio
            
            # Expand bbox
            expanded_bbox = [
                [max(0, int(min_x - x_expansion)), max(0, int(min_y - y_expansion))],
                [int(max_x + x_expansion), max(0, int(min_y - y_expansion))],
                [int(max_x + x_expansion), int(max_y + y_expansion)],
                [max(0, int(min_x - x_expansion)), int(max_y + y_expansion)]
            ]
            
            return expanded_bbox
            
        except Exception as e:
            logger.error(f"Error expanding bbox: {str(e)}")
            return bbox
