"""
File handling utilities for validation and management
"""

import os
import logging
from typing import List, Set
import mimetypes

logger = logging.getLogger(__name__)

class FileHandler:
    def __init__(self):
        """Initialize file handler"""
        # Supported image formats
        self.image_extensions: Set[str] = {
            '.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tiff', '.gif'
        }
        
        # Supported archive formats
        self.archive_extensions: Set[str] = {
            '.zip', '.rar', '.cbz', '.cbr'
        }
        
        # Supported document formats
        self.document_extensions: Set[str] = {
            '.pdf'
        }
        
        # All supported extensions
        self.supported_extensions: Set[str] = (
            self.image_extensions | self.archive_extensions | self.document_extensions
        )
        
        # Supported MIME types
        self.supported_mimes: Set[str] = {
            'image/png', 'image/jpeg', 'image/webp', 
            'image/bmp', 'image/tiff', 'image/gif',
            'application/pdf',
            'application/zip', 'application/x-rar-compressed',
            'application/x-cbr', 'application/x-cbz'
        }
        
        logger.info("File handler initialized")
    
    def is_valid_file(self, filename: str) -> bool:
        """
        Check if file is a supported format (image, PDF, or archive)
        
        Args:
            filename: Name of the file
            
        Returns:
            True if file is supported
        """
        try:
            if not filename:
                return False
            
            # Check extension
            _, ext = os.path.splitext(filename.lower())
            if ext not in self.supported_extensions:
                return False
            
            # Check MIME type
            mime_type, _ = mimetypes.guess_type(filename)
            if mime_type and mime_type not in self.supported_mimes:
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating file {filename}: {str(e)}")
            return False
    
    def get_safe_filename(self, filename: str) -> str:
        """
        Generate a safe filename by removing/replacing unsafe characters
        
        Args:
            filename: Original filename
            
        Returns:
            Safe filename
        """
        try:
            # Remove path components
            basename = os.path.basename(filename)
            
            # Replace unsafe characters
            safe_chars = []
            for char in basename:
                if char.isalnum() or char in '.-_':
                    safe_chars.append(char)
                else:
                    safe_chars.append('_')
            
            safe_filename = ''.join(safe_chars)
            
            # Ensure it's not empty and has an extension
            if not safe_filename or safe_filename.startswith('.'):
                safe_filename = 'image' + safe_filename
            
            return safe_filename
            
        except Exception as e:
            logger.error(f"Error creating safe filename: {str(e)}")
            return 'image.png'
    
    def validate_file_size(self, file_size: int, max_size: int) -> bool:
        """
        Validate file size
        
        Args:
            file_size: Size of file in bytes
            max_size: Maximum allowed size in bytes
            
        Returns:
            True if file size is acceptable
        """
        return 0 < file_size <= max_size
    
    def get_file_info(self, filename: str, file_size: int) -> dict:
        """
        Get comprehensive file information
        
        Args:
            filename: Name of the file
            file_size: Size of file in bytes
            
        Returns:
            Dictionary with file information
        """
        try:
            _, ext = os.path.splitext(filename.lower())
            mime_type, _ = mimetypes.guess_type(filename)
            
            return {
                'filename': filename,
                'safe_filename': self.get_safe_filename(filename),
                'extension': ext,
                'mime_type': mime_type,
                'size_bytes': file_size,
                'size_mb': round(file_size / (1024 * 1024), 2),
                'is_valid': self.is_valid_image_file(filename)
            }
            
        except Exception as e:
            logger.error(f"Error getting file info: {str(e)}")
            return {
                'filename': filename,
                'safe_filename': 'unknown.png',
                'extension': '.png',
                'mime_type': 'image/png',
                'size_bytes': file_size,
                'size_mb': round(file_size / (1024 * 1024), 2),
                'is_valid': False
            }
    
    def cleanup_temp_files(self, file_paths: List[str]):
        """
        Clean up temporary files
        
        Args:
            file_paths: List of file paths to remove
        """
        for file_path in file_paths:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    logger.debug(f"Removed temp file: {file_path}")
            except Exception as e:
                logger.error(f"Error removing temp file {file_path}: {str(e)}")
    
    def is_image_file(self, filename: str) -> bool:
        """Check if file is an image"""
        _, ext = os.path.splitext(filename.lower())
        return ext in self.image_extensions
    
    def is_pdf_file(self, filename: str) -> bool:
        """Check if file is a PDF"""
        _, ext = os.path.splitext(filename.lower())
        return ext in self.document_extensions
    
    def is_archive_file(self, filename: str) -> bool:
        """Check if file is an archive"""
        _, ext = os.path.splitext(filename.lower())
        return ext in self.archive_extensions
    
    def extract_images_from_pdf(self, pdf_path: str, temp_dir: str) -> List[str]:
        """
        Extract pages from PDF as images
        
        Args:
            pdf_path: Path to PDF file
            temp_dir: Temporary directory for extracted images
            
        Returns:
            List of paths to extracted image files
        """
        try:
            from pdf2image import convert_from_path
            
            # Convert PDF pages to images
            images = convert_from_path(pdf_path, dpi=300, thread_count=2)
            
            image_paths = []
            for i, image in enumerate(images):
                image_path = os.path.join(temp_dir, f"page_{i+1}.png")
                image.save(image_path, "PNG")
                image_paths.append(image_path)
                logger.debug(f"Extracted page {i+1} to {image_path}")
            
            logger.info(f"Extracted {len(image_paths)} pages from PDF")
            return image_paths
            
        except Exception as e:
            logger.error(f"Error extracting images from PDF: {str(e)}")
            return []
    
    def extract_images_from_archive(self, archive_path: str, temp_dir: str) -> List[str]:
        """
        Extract images from archive file
        
        Args:
            archive_path: Path to archive file
            temp_dir: Temporary directory for extracted files
            
        Returns:
            List of paths to extracted image files
        """
        try:
            import zipfile
            import rarfile
            from pyunpack import Archive
            
            _, ext = os.path.splitext(archive_path.lower())
            extracted_dir = os.path.join(temp_dir, "extracted")
            os.makedirs(extracted_dir, exist_ok=True)
            
            # Extract based on file type
            if ext == '.zip' or ext == '.cbz':
                with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                    zip_ref.extractall(extracted_dir)
            elif ext == '.rar' or ext == '.cbr':
                with rarfile.RarFile(archive_path, 'r') as rar_ref:
                    rar_ref.extractall(extracted_dir)
            else:
                # Use pyunpack for other formats
                Archive(archive_path).extractall(extracted_dir)
            
            # Find all image files in extracted directory
            image_paths = []
            for root, dirs, files in os.walk(extracted_dir):
                for file in files:
                    if self.is_image_file(file):
                        image_paths.append(os.path.join(root, file))
            
            # Sort image paths naturally (for proper page order)
            image_paths.sort()
            
            logger.info(f"Extracted {len(image_paths)} images from archive")
            return image_paths
            
        except Exception as e:
            logger.error(f"Error extracting images from archive: {str(e)}")
            return []
